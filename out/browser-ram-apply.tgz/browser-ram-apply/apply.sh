#!/bin/sh
set -eu
BASE=$(CDPATH= cd -- "$(dirname "$0")" && pwd)
sudo install -D -m0755 "$BASE/usr/local/bin/etheris-browser" /usr/local/bin/etheris-browser
sudo install -D -m0644 "$BASE/etc/firefox/policies/policies.json" /etc/firefox/policies/policies.json
mkdir -p "$HOME/.config/sway" "$HOME/.config/etheris"
# Preserve user settings; only add missing keys
CONF="$HOME/.config/etheris/settings.conf"
if [ -f "$CONF" ]; then
  grep -qE '^browser_preload=' "$CONF" 2>/dev/null || echo 'browser_preload=on' >>"$CONF"
  grep -qE '^default_browser=' "$CONF" 2>/dev/null || echo 'default_browser=firefox' >>"$CONF"
else
  cp -f "$BASE/etc/skel/.config/etheris/settings.conf" "$CONF"
fi
# Merge preload timing into live sway config if present
if [ -f "$HOME/.config/sway/config" ]; then
  sed -i \
    -e 's/sleep 1\.2; etheris-browser --preload/sleep 0.35; etheris-browser --preload/' \
    -e 's/sleep 1\.2; etheris-timezone/sleep 2.5; etheris-timezone/' \
    -e 's/sleep 8; etheris-timezone-auto/sleep 12; etheris-timezone-auto/' \
    "$HOME/.config/sway/config" || true
  if ! grep -q 'etheris-browser --preload' "$HOME/.config/sway/config"; then
    # Insert after polkit agent line when missing
    awk '
      /polkit-gnome-authentication-agent/ && !done {
        print
        print "# Warm Firefox in the scratchpad early so Super+B is typically <1s"
        print "exec sh -c '\''sleep 0.35; etheris-browser --preload'\''"
        done=1
        next
      }
      { print }
    ' "$HOME/.config/sway/config" >"$HOME/.config/sway/config.tmp" \
      && mv "$HOME/.config/sway/config.tmp" "$HOME/.config/sway/config"
  fi
else
  cp -f "$BASE/etc/skel/.config/sway/config" "$HOME/.config/sway/config"
fi
pkill -x firefox 2>/dev/null || true
sleep 0.2
etheris-browser --preload
swaymsg reload 2>/dev/null || true
echo "OK: lean Firefox policies + warm preload active"
etheris-browser --status || true
