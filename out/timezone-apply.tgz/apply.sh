#!/bin/sh
set -eu
BASE=$(CDPATH= cd -- "$(dirname "$0")" && pwd)
sudo install -D -m0755 "$BASE/usr/local/bin/ethereal-timezone" /usr/local/bin/ethereal-timezone
sudo install -D -m0755 "$BASE/usr/local/bin/ethereal" /usr/local/bin/ethereal
sudo install -D -m0755 "$BASE/usr/local/bin/ethereal-settings" /usr/local/bin/ethereal-settings
sudo mkdir -p /usr/local/share/ethereal/timezone
sudo cp -a "$BASE/usr/local/share/ethereal/timezone/." /usr/local/share/ethereal/timezone/
sudo install -D -m0644 "$BASE/usr/share/applications/ethereal-timezone.desktop" /usr/share/applications/ethereal-timezone.desktop
mkdir -p "$HOME/.config/sway/config.d"
cp -f "$BASE/etc/skel/.config/sway/config" "$HOME/.config/sway/config"
cp -f "$BASE/etc/skel/.config/sway/config.d/40-ethereal-defaults" "$HOME/.config/sway/config.d/"
# WebKit for the 3D globe
if ! pacman -Q webkitgtk-6.0 >/dev/null 2>&1; then
  echo "Installing webkitgtk-6.0…"
  sudo pacman -S --needed --noconfirm webkitgtk-6.0 || true
fi
swaymsg reload 2>/dev/null || true
rm -f "$HOME/.config/ethereal/timezone-done"
echo OK_TZ
# Launch globe (force)
ethereal-timezone --force >/tmp/ethereal-timezone.log 2>&1 &
echo UI_STARTED
