#!/bin/sh
set -eu
BASE=$(CDPATH= cd -- "$(dirname "$0")" && pwd)
for f in ethereal-defaults ethereal-defaults-ui ethereal-terminal ethereal-agent ethereal-browsers ethereal-browsers-ui ethereal-browser ethereal-settings ethereal ethereal-control-center ethereal-launcher; do
  sudo install -D -m0755 "$BASE/usr/local/bin/$f" "/usr/local/bin/$f"
done
sudo install -D -m0644 "$BASE/usr/local/share/ethereal/defaults/catalog.json" /usr/local/share/ethereal/defaults/catalog.json
sudo install -D -m0755 "$BASE/usr/local/share/ethereal/rofi/favorites.mode" /usr/local/share/ethereal/rofi/favorites.mode
sudo install -D -m0644 "$BASE/usr/share/applications/ethereal-defaults.desktop" /usr/share/applications/ethereal-defaults.desktop
sudo install -D -m0644 "$BASE/usr/share/applications/ethereal-browsers.desktop" /usr/share/applications/ethereal-browsers.desktop
sudo install -D -m0644 "$BASE/usr/local/share/applications/ethereal-defaults.desktop" /usr/local/share/applications/ethereal-defaults.desktop 2>/dev/null || true
mkdir -p "$HOME/.config/sway" "$HOME/.config/ethereal"
cp -f "$BASE/etc/skel/.config/sway/config" "$HOME/.config/sway/config"
cp -f "$BASE/etc/skel/.config/ethereal/launcher-pins.conf" "$HOME/.config/ethereal/launcher-pins.conf"
update-desktop-database /usr/share/applications /usr/local/share/applications 2>/dev/null || true
swaymsg reload 2>/dev/null || true
echo OK_DEFAULTS
GSK_RENDERER=cairo ethereal-defaults >/tmp/ethereal-defaults-ui.log 2>&1 &
sleep 1
echo UI_STARTED
