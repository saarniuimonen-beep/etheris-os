#!/bin/sh
set -eu
BASE=$(CDPATH= cd -- "$(dirname "$0")" && pwd)
for f in ethereal-launcher ethereal-defaults-ui ethereal-settings ethereal-control-center ethereal ethereal-theme-apply; do
  sudo install -D -m0755 "$BASE/usr/local/bin/$f" "/usr/local/bin/$f"
done
sudo install -D -m0644 "$BASE/usr/local/share/ethereal/rofi/ethereal.rasi" /usr/local/share/ethereal/rofi/ethereal.rasi
sudo install -D -m0644 "$BASE/usr/local/share/ethereal/rofi/ethereal-slim.rasi" /usr/local/share/ethereal/rofi/ethereal-slim.rasi
sudo install -D -m0644 "$BASE/usr/local/share/ethereal/design/templates/rofi.ethereal.rasi.tmpl" /usr/local/share/ethereal/design/templates/rofi.ethereal.rasi.tmpl
sudo install -D -m0644 "$BASE/usr/local/share/ethereal/design/templates/rofi.ethereal-slim.rasi.tmpl" /usr/local/share/ethereal/design/templates/rofi.ethereal-slim.rasi.tmpl
mkdir -p "$HOME/.config/rofi" "$HOME/.config/ethereal"
cp -f /usr/local/share/ethereal/rofi/ethereal.rasi "$HOME/.config/rofi/ethereal.rasi"
cp -f /usr/local/share/ethereal/rofi/ethereal-slim.rasi "$HOME/.config/rofi/ethereal-slim.rasi"
# keep existing settings; ensure launcher_style key exists
if ! grep -qE '^launcher_style=' "$HOME/.config/ethereal/settings.conf" 2>/dev/null; then
  echo 'launcher_style=wide' >> "$HOME/.config/ethereal/settings.conf"
fi
ethereal-theme-apply >/dev/null 2>&1 || true
pkill -f ethereal-defaults-ui 2>/dev/null || true
sleep 0.2
GSK_RENDERER=cairo ethereal-defaults >/tmp/ethereal-defaults-ui.log 2>&1 &
echo OK_UI_LAUNCHER
