#!/bin/sh
set -eu
BASE=$(CDPATH= cd -- "$(dirname "$0")" && pwd)
sudo install -D -m0755 "$BASE/usr/local/bin/ethereal-timezone" /usr/local/bin/ethereal-timezone
sudo install -D -m0755 "$BASE/usr/local/bin/ethereal-timezone-auto" /usr/local/bin/ethereal-timezone-auto
[ -f "$BASE/usr/local/bin/ethereal-settings" ] && sudo install -D -m0755 "$BASE/usr/local/bin/ethereal-settings" /usr/local/bin/ethereal-settings
[ -f "$BASE/usr/local/bin/ethereal" ] && sudo install -D -m0755 "$BASE/usr/local/bin/ethereal" /usr/local/bin/ethereal
sudo mkdir -p /usr/local/share/ethereal/timezone
sudo cp -a "$BASE/usr/local/share/ethereal/timezone/." /usr/local/share/ethereal/timezone/
mkdir -p "$HOME/.config/sway" "$HOME/.config/ethereal"
cp -f "$BASE/etc/skel/.config/sway/config" "$HOME/.config/sway/config"
touch "$HOME/.config/ethereal/settings.conf"
grep -qE '^timezone_auto=' "$HOME/.config/ethereal/settings.conf" 2>/dev/null || echo 'timezone_auto=on' >> "$HOME/.config/ethereal/settings.conf"
swaymsg reload 2>/dev/null || true
pkill -f 'ethereal-timezone-auto' 2>/dev/null || true
pkill -f 'ethereal-timezone' 2>/dev/null || true
sleep 0.4
pacman -Q webkitgtk-6.0 >/dev/null 2>&1 || sudo pacman -S --needed --noconfirm webkitgtk-6.0 || true
ethereal-timezone-auto --daemon >/tmp/ethereal-tz-auto.log 2>&1 &
rm -f "$HOME/.config/ethereal/timezone-done"
# Prefer polished GTK in virtio VMs; WebKit globe still tried first unless ETHEREAL_TZ_FALLBACK=1
if [ "${ETHEREAL_TZ_FALLBACK:-1}" = "1" ]; then
  GSK_RENDERER=cairo ethereal-timezone --force --fallback >/tmp/ethereal-timezone.log 2>&1 &
else
  GSK_RENDERER=cairo ethereal-timezone --force >/tmp/ethereal-timezone.log 2>&1 &
fi
echo OK_TZ_POLISH
