#!/bin/sh
set -eu
BASE=$(CDPATH= cd -- "$(dirname "$0")" && pwd)
sudo install -D -m0755 "$BASE/usr/local/bin/ethereal-browser" /usr/local/bin/ethereal-browser
sudo install -D -m0755 "$BASE/usr/local/bin/ethereal-browsers" /usr/local/bin/ethereal-browsers
sudo install -D -m0755 "$BASE/usr/local/bin/ethereal-browsers-ui" /usr/local/bin/ethereal-browsers-ui
sudo install -D -m0755 "$BASE/usr/local/bin/ethereal-settings" /usr/local/bin/ethereal-settings
sudo install -D -m0755 "$BASE/usr/local/bin/ethereal" /usr/local/bin/ethereal
sudo install -D -m0755 "$BASE/usr/local/bin/ethereal-control-center" /usr/local/bin/ethereal-control-center
sudo install -D -m0644 "$BASE/usr/local/share/ethereal/browsers/catalog.json" /usr/local/share/ethereal/browsers/catalog.json
sudo install -D -m0755 "$BASE/usr/local/share/ethereal/rofi/favorites.mode" /usr/local/share/ethereal/rofi/favorites.mode
sudo install -D -m0644 "$BASE/usr/share/applications/ethereal-browsers.desktop" /usr/share/applications/ethereal-browsers.desktop
sudo install -D -m0644 "$BASE/usr/local/share/applications/ethereal-browsers.desktop" /usr/local/share/applications/ethereal-browsers.desktop
update-desktop-database /usr/local/share/applications /usr/share/applications 2>/dev/null || true
echo OK_BROWSERS
ethereal-browsers list || true
