#!/usr/bin/env bash
set -euo pipefail
BASE="$(cd "$(dirname "$0")" && pwd)"
sudo install -D -m0755 "$BASE/usr/local/bin/etheris-defaults" /usr/local/bin/etheris-defaults
sudo install -D -m0755 "$BASE/usr/local/bin/etheris-defaults-ui" /usr/local/bin/etheris-defaults-ui
sudo install -D -m0755 "$BASE/usr/local/bin/etheris-steam" /usr/local/bin/etheris-steam
sudo install -D -m0755 "$BASE/usr/local/bin/etheris-gaming-setup" /usr/local/bin/etheris-gaming-setup
sudo install -D -m0755 "$BASE/usr/local/bin/etheris-installer" /usr/local/bin/etheris-installer
sudo install -D -m0644 "$BASE/usr/local/share/etheris/gaming-packages.list" /usr/local/share/etheris/gaming-packages.list
sudo install -D -m0644 "$BASE/usr/local/share/etheris/docs/GAMING.md" /usr/local/share/etheris/docs/GAMING.md
# Refresh gaming user setup
etheris-gaming-setup force || true
echo "Applied gaming + defaults fixes. Re-open Defaults / Steam."
