#!/bin/sh
set -eu
BASE=$(CDPATH= cd -- "$(dirname "$0")" && pwd)
sudo install -D -m0755 "$BASE/usr/local/bin/ethereal-browser" /usr/local/bin/ethereal-browser
sudo install -D -m0755 "$BASE/usr/local/bin/ethereal-launcher" /usr/local/bin/ethereal-launcher
sudo install -D -m0644 "$BASE/usr/local/share/applications/ethereal-browser.desktop" /usr/local/share/applications/ethereal-browser.desktop
sudo install -D -m0644 "$BASE/usr/local/share/applications/firefox.desktop" /usr/local/share/applications/firefox.desktop
sudo install -D -m0755 "$BASE/usr/local/share/ethereal/rofi/favorites.mode" /usr/local/share/ethereal/rofi/favorites.mode
sudo install -D -m0644 "$BASE/etc/firefox/policies/policies.json" /etc/firefox/policies/policies.json
mkdir -p "$HOME/.config/sway" "$HOME/.config/ethereal"
cp -f "$BASE/etc/skel/.config/sway/config" "$HOME/.config/sway/config"
cp -f "$BASE/etc/skel/.config/mimeapps.list" "$HOME/.config/mimeapps.list"
cp -f "$BASE/etc/skel/.config/ethereal/launcher-pins.conf" "$HOME/.config/ethereal/launcher-pins.conf"
update-desktop-database "$HOME/.local/share/applications" 2>/dev/null || true
update-desktop-database /usr/local/share/applications 2>/dev/null || true
# Start warm browser now (no session restart needed)
pkill -x firefox 2>/dev/null || true
sleep 0.3
ethereal-browser --preload
# Reload sway config so Super+B and future exec lines exist
swaymsg reload 2>/dev/null || true
echo "OK: ethereal-browser installed + preloading"
